const emailInput = document.querySelector("#email-input");
const otpField = document.querySelector("#otp-field");
const sendOTPBtn = document.querySelector("#send-otp-btn");
const submitBtn = document.querySelector("#submit-btn");
const verifyBtn = document.getElementById("verify-btn");
const afterEmail = document.querySelector("#email-output");
const signUpForm = document.querySelector("#sign-up-form");
const passDiv = document.querySelector("#pass-div");

let otp;

sendOTPBtn.addEventListener("click", () => {
  
  const email = emailInput.value;
  if (!isValidEmail(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  var text = document.createTextNode(emailInput.value);

  console.log(afterEmail);
  afterEmail.appendChild(text);

  emailInput.style.display = "none";
  afterEmail.style.display = "block"; 

  sendOTPBtn.style.display = "none";

  console.log(verifyBtn);
  
  otpField.style.display = "block";
  // submitBtn.style.display = "block";
  verifyBtn.style.display = "block";
  
  otp = generateOTP();
  alert(`OTP sent to ${email}: ${otp}`);

});

verifyBtn.addEventListener("click", () => {


    alert("OTP verified");
    otpField.style.display = "none";
    verifyBtn.style.display = "none";
    signUpForm.style.display = "none";
    passDiv.style.display = "block";
  
});


function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}


function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});
